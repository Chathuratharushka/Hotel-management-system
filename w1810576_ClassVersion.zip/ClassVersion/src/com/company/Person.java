package com.company;

public class Person {
    String firstName;
    String surname;
    long creditCardNumber;

    Person(){
        firstName="empty";
        surname="No customer";
        creditCardNumber=0;
    }
}
